### Tuts+ Tutorial: Getting Started With RecyclerView and CardView on Android

#### Instructor: Hathibelagal Ashraff

Android Lollipop introduced two new widgets, RecyclerView and CardView. In this tutorial, you will learn how to make use of these widgets to quickly create apps whose look and feel conforms to the guidelines mentioned in Google's Material Design specification.

Source files for the Tuts+ tutorial: [Getting Started With RecyclerView and CardView on Android](http://code.tutsplus.com/tutorials/getting-started-with-recyclerview-and-cardview-on-android--cms-23465)

**Read this tutorial on [Tuts+](https://code.tutsplus.com)**
